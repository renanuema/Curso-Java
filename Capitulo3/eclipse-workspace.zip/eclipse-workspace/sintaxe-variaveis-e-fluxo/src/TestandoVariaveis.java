
public class TestandoVariaveis {

	public static void main(String[] args) {
		System.out.println("ola novo teste");
	
		int idade;
		idade = 31;
		
		System.out.println(idade);
		
		idade = 20 + 11;
		
		System.out.println(idade);
		
		idade = 5 * 6 + 1;
		
		System.out.println("a idade é " + idade);
		
	}
	
}
