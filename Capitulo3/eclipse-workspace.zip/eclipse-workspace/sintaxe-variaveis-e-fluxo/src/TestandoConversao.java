
public class TestandoConversao {

	public static void main(String[] args) {
		double salario = 3500.22;
		int valor = (int) salario;
		System.out.println(valor);

		long numeroGrande = 32432423523L;
		short valorPequeno = 2131;
		byte b = 127;
		
		double valor1 = 0.2;
		double valor2 = 0.1;
		double total = valor1 + valor2;
		
		System.out.println (total);
				
	}

}
