
public class TestandoPontoFlutuante {

	public static void main(String[] args) {
		
	double salario;
	salario = 3922.90;
		
	System.out.println("meu salário é " + salario);
	
	double divisao = 3.14/2;
	System.out.println("resultado da divisao = " + divisao);
	
	double divisaoInteiros = 5/2;
	System.out.println("resultado da outra divisao = " + divisaoInteiros);	
	
	double divisaoDecimal = 5.0/2;
	System.out.println("resultado da outra divisao = " + divisaoDecimal);	
	}
		
}
