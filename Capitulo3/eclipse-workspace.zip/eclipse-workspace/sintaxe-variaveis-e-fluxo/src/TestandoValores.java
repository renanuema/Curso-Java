
public class TestandoValores {

	public static void main(String[] args) {
		
		int primeiro = 5;
		int segundo = 7;
		segundo = primeiro;
		
		System.out.println(segundo);
		
	}

}
